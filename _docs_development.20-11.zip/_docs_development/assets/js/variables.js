var page_url = "/assets/js/variables.js";
var site_baseurl = "";
